import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

// Load environment variables for local testing
dotenv.config();

import { 
  Teacher, 
  Classroom, 
  TeachingClass, 
  Student, 
  ScheduleItem, 
  Conflict, 
  TimeSlot, 
  SubstituteRecommendation 
} from './src/types';

import { 
  INITIAL_TEACHERS, 
  INITIAL_CLASSROOMS, 
  INITIAL_TEACHING_CLASSES, 
  INITIAL_STUDENTS, 
  generatePrepopulatedSchedules 
} from './src/mockData';

const app = express();
app.use(express.json());

const PORT = 3000;

// Initialize shared memory DB states
let teachers: Teacher[] = JSON.parse(JSON.stringify(INITIAL_TEACHERS));
let classrooms: Classroom[] = JSON.parse(JSON.stringify(INITIAL_CLASSROOMS));
let teachingClasses: TeachingClass[] = JSON.parse(JSON.stringify(INITIAL_TEACHING_CLASSES));
let students: Student[] = JSON.parse(JSON.stringify(INITIAL_STUDENTS));
let schedules: ScheduleItem[] = generatePrepopulatedSchedules(teachers, classrooms, teachingClasses);
let histories: { id: string; name: string; timestamp: string; description: string; items: ScheduleItem[] }[] = [];

// System constraints settings for NP-hard conflict resolution & fault tolerance
let configSettings = {
  hardStudentConflict: true, // "走班学生无重合冲突（排课硬性底线）"
  hardTeacherConflict: true, // "任课教师授课时段无重叠碰撞（排课硬性底线）"
  hardClassroomConflict: true, // "授课教室占用无交叉碰撞（排课硬性底线）"
  allowTeacherPrefRelaxation: false, // "放宽教师个人工作段弹性偏好软约束（降级高难度排课约束）"
  allowClassroomLoadRelaxation: false, // "放宽理化实验室等专属机房弹性负荷容载度限额 (上限提升10%)"
};

// Dummy reference to satisfy compile requirements on other reset routes
let aiInsightsCache: any = null;

// Conflict Detection Function
function detectConflicts(currentSchedules: ScheduleItem[], currentTeachers: Teacher[], currentClassrooms: Classroom[], currentClasses: TeachingClass[]): Conflict[] {
  const conflicts: Conflict[] = [];
  let conflictCounter = 0;

  // Let's index items by Day & Period to find collisions
  const slotMap: { [slotKey: string]: ScheduleItem[] } = {};
  for (const item of currentSchedules) {
    if (item.isFinished) continue; // ignore early finished classes
    const key = `${item.day}-${item.period}`;
    if (!slotMap[key]) slotMap[key] = [];
    slotMap[key].push(item);
  }

  for (const [key, items] of Object.entries(slotMap)) {
    const [dayStr, periodStr] = key.split('-');
    const day = parseInt(dayStr);
    const period = parseInt(periodStr);

    // 1. Teacher Conflicts: Same teacher cannot have multiple lessons at the same time
    const teacherMap: { [teacherId: string]: ScheduleItem[] } = {};
    for (const item of items) {
      if (!teacherMap[item.teacherId]) teacherMap[item.teacherId] = [];
      teacherMap[item.teacherId].push(item);
    }
    for (const [teacherId, colliding] of Object.entries(teacherMap)) {
      if (colliding.length > 1) {
        const teacher = currentTeachers.find(t => t.id === teacherId);
        const name = teacher ? teacher.name : "未知教师";
        conflicts.push({
          id: `conflict_${conflictCounter++}`,
          type: 'teacher',
          severity: 'critical',
          message: `教师冲突: ${name} 分配了多个走班教学班（${colliding.map(c => c.teachingClassName).join(' 和 ')}）`,
          targetId: teacherId,
          affectedSlots: [{ day, period }],
          involvedScheduleIds: colliding.map(c => c.id)
        });
      }
    }

    // 2. Classroom Conflicts: Same classroom cannot host multiple lessons at the same time
    const classroomMap: { [classroomId: string]: ScheduleItem[] } = {};
    for (const item of items) {
      if (!classroomMap[item.classroomId]) classroomMap[item.classroomId] = [];
      classroomMap[item.classroomId].push(item);
    }
    for (const [classroomId, colliding] of Object.entries(classroomMap)) {
      if (colliding.length > 1) {
        const classroom = currentClassrooms.find(r => r.id === classroomId);
        const name = classroom ? classroom.name : "未知教师";
        conflicts.push({
          id: `conflict_${conflictCounter++}`,
          type: 'classroom',
          severity: 'critical',
          message: `校舍占用冲突: 教室 ${name} 同时承载了多个课程（${colliding.map(c => c.teachingClassName).join(' 和 ')}）`,
          targetId: classroomId,
          affectedSlots: [{ day, period }],
          involvedScheduleIds: colliding.map(c => c.id)
        });
      }
    }

    // 3. Student Elective Combination Conflicts (走班冲突检测): 
    // If multiple classes share students of the same elective combination (e.g. 物化生, 物化地), they shouldn't run at the same day/period,
    // otherwise those students cannot be at two different classrooms at once.
    // For every student, let's map what classes they are taking.
    // If a student belongs to multiple classes running at the exact same day/period, that's a student conflict!
    const studentSchedules = new Map<string, ScheduleItem[]>(); // studentId -> ScheduleItem[]
    for (const s of students) {
      for (const item of items) {
        const tClass = currentClasses.find(c => c.id === item.teachingClassId);
        if (tClass) {
          // Check if student belongs to this teaching class
          // Compulsory base classes (C001, C002, etc.) contain standard administrative setups.
          // Or we can match electiveCombo tags as teaching combinations 
          const studentTakesCompulsory = (s.electiveCombo === "物化生" && tClass.id === "C001") ||
                                         (s.electiveCombo === "物化地" && tClass.id === "C001") ||
                                         (s.electiveCombo === "史化地" && tClass.id === "C002");
          
          const studentTakesElective = (s.electiveCombo === tClass.combination);

          const studentTakesMath = (s.electiveCombo === "物化生" && tClass.id === "C003") ||
                                   (s.electiveCombo === "物化地" && tClass.id === "C003") ||
                                   (s.electiveCombo === "史化地" && tClass.id === "C004");

          const studentTakesGeneral = (tClass.id === "C013" || tClass.id === "C012" || tClass.id === "C014");

          if (studentTakesCompulsory || studentTakesElective || studentTakesMath || studentTakesGeneral) {
            if (!studentSchedules.has(s.id)) studentSchedules.set(s.id, []);
            studentSchedules.get(s.id)!.push(item);
          }
        }
      }
    }

    for (const [studentId, studentItems] of studentSchedules.entries()) {
      if (studentItems.length > 1) {
        const student = students.find(s => s.id === studentId);
        const name = student ? student.name : "未知学生";
        conflicts.push({
          id: `conflict_${conflictCounter++}`,
          type: 'student',
          severity: 'critical',
          message: `走班选科冲突: 学生 ${name} (${student?.electiveCombo}) 的教学班（${studentItems.map(c => c.teachingClassName).join(' 和 ')}）排在同一时段，导致学生分身乏术。`,
          targetId: studentId,
          affectedSlots: [{ day, period }],
          involvedScheduleIds: studentItems.map(c => c.id)
        });
      }
    }
  }

  // 4. Teacher Preferences & Unavailable Times Soft Conflicts
  if (!configSettings.allowTeacherPrefRelaxation) {
    for (const item of currentSchedules) {
      if (item.isFinished) continue;
      const teacher = currentTeachers.find(t => t.id === item.teacherId);
      if (teacher) {
        const isUnavailable = teacher.unavailablePeriods.some(p => p.day === item.day && p.period === item.period);
        if (isUnavailable) {
          conflicts.push({
            id: `conflict_${conflictCounter++}`,
            type: 'constraint',
            severity: 'warning',
            message: `教师偏好软约束：${teacher.name} 老师在周${item.day}第${item.period}节被手动排了课（${item.teachingClassName}），这属于该教师偏好的不可排时段限制（可通过勾选规则面板的“高柔性放宽教师偏好”予以容错忽略）。`,
            targetId: teacher.id,
            affectedSlots: [{ day: item.day, period: item.period }],
            involvedScheduleIds: [item.id]
          });
        }
      }
    }
  }

  // 5. Classroom resource overload warnings (Soft constraint)
  if (!configSettings.allowClassroomLoadRelaxation) {
    for (const room of currentClassrooms) {
      if (room.type === 'lab' || room.type === 'media') {
        const lessonsCount = currentSchedules.filter(s => s.classroomId === room.id && !s.isFinished).length;
        if (lessonsCount > 10) {
          conflicts.push({
            id: `conflict_${conflictCounter++}`,
            type: 'constraint',
            severity: 'warning',
            message: `高端实验室负载弹性警告：${room.name} 本周被安排了开设走班课程 ${lessonsCount} 节，使用频次较高，建议错峰排放以减少损耗（可勾选规则面板的“放宽理化实验室预警”实施低警报容忍）。`,
            targetId: room.id,
            affectedSlots: [],
            involvedScheduleIds: []
          });
        }
      }
    }
  }

  return conflicts;
}

// ---------------- REST APIs ----------------

// Base fetch and metadata Reset endpoint
app.get('/api/data', (req, res) => {
  const currentConflicts = detectConflicts(schedules, teachers, classrooms, teachingClasses);
  res.json({
    teachers,
    classrooms,
    teachingClasses,
    students,
    schedules,
    histories,
    conflicts: currentConflicts,
    configSettings
  });
});

app.get('/api/config', (req, res) => {
  res.json(configSettings);
});

app.post('/api/config', (req, res) => {
  configSettings = { ...configSettings, ...req.body };
  const currentConflicts = detectConflicts(schedules, teachers, classrooms, teachingClasses);
  res.json({
    status: 'success',
    configSettings,
    conflicts: currentConflicts
  });
});

app.post('/api/reset', (req, res) => {
  teachers = JSON.parse(JSON.stringify(INITIAL_TEACHERS));
  classrooms = JSON.parse(JSON.stringify(INITIAL_CLASSROOMS));
  teachingClasses = JSON.parse(JSON.stringify(INITIAL_TEACHING_CLASSES));
  students = JSON.parse(JSON.stringify(INITIAL_STUDENTS));
  schedules = generatePrepopulatedSchedules(teachers, classrooms, teachingClasses);
  histories = [];
  aiInsightsCache = null;
  
  const currentConflicts = detectConflicts(schedules, teachers, classrooms, teachingClasses);
  res.json({
    status: 'success',
    teachers,
    classrooms,
    teachingClasses,
    schedules,
    conflicts: currentConflicts
  });
});

// CRUD for Teachers
app.post('/api/teachers', (req, res) => {
  const newTeacher: Teacher = {
    id: `T${String(teachers.length + 1).padStart(3, '0')}`,
    ...req.body,
    unavailablePeriods: req.body.unavailablePeriods || []
  };
  teachers.push(newTeacher);
  aiInsightsCache = null;
  res.json({ status: 'success', teacher: newTeacher });
});

app.put('/api/teachers/:id', (req, res) => {
  const index = teachers.findIndex(t => t.id === req.params.id);
  if (index !== -1) {
    teachers[index] = { ...teachers[index], ...req.body };
    aiInsightsCache = null;
    res.json({ status: 'success', teacher: teachers[index] });
  } else {
    res.status(404).json({ error: 'Teacher not found' });
  }
});

app.delete('/api/teachers/:id', (req, res) => {
  teachers = teachers.filter(t => t.id !== req.params.id);
  schedules = schedules.filter(s => s.teacherId !== req.params.id);
  aiInsightsCache = null;
  res.json({ status: 'success' });
});

// CRUD for Classrooms
app.post('/api/classrooms', (req, res) => {
  const newClassroom: Classroom = {
    id: `R${String(classrooms.length + 1).padStart(3, '0')}`,
    ...req.body
  };
  classrooms.push(newClassroom);
  aiInsightsCache = null;
  res.json({ status: 'success', classroom: newClassroom });
});

app.put('/api/classrooms/:id', (req, res) => {
  const index = classrooms.findIndex(c => c.id === req.params.id);
  if (index !== -1) {
    classrooms[index] = { ...classrooms[index], ...req.body };
    aiInsightsCache = null;
    res.json({ status: 'success', classroom: classrooms[index] });
  } else {
    res.status(404).json({ error: 'Classroom not found' });
  }
});

// Drag and drop or manual edit individual cell schedule upgrade/update representation
app.post('/api/schedules/update-slot', (req, res) => {
  const { scheduleItemId, newDay, newPeriod } = req.body;
  const index = schedules.findIndex(s => s.id === scheduleItemId);
  if (index !== -1) {
    schedules[index].day = newDay;
    schedules[index].period = newPeriod;
    schedules[index].isTemp = true; // Flagged as dynamic modifier
    aiInsightsCache = null;
    
    const currentConflicts = detectConflicts(schedules, teachers, classrooms, teachingClasses);
    res.json({ status: 'success', schedules, conflicts: currentConflicts });
  } else {
    res.status(404).json({ error: 'Schedule item not found' });
  }
});

// Schedule dynamic override (such as temporary teacher adjustment)
app.post('/api/schedules/override-teacher', (req, res) => {
  const { scheduleItemId, substituteTeacherId } = req.body;
  const index = schedules.findIndex(s => s.id === scheduleItemId);
  const teacherObj = teachers.find(t => t.id === substituteTeacherId);
  if (index !== -1 && teacherObj) {
    schedules[index].teacherId = substituteTeacherId;
    schedules[index].teacherName = teacherObj.name;
    schedules[index].isTemp = true;
    aiInsightsCache = null;

    const currentConflicts = detectConflicts(schedules, teachers, classrooms, teachingClasses);
    res.json({ status: 'success', schedules, conflicts: currentConflicts });
  } else {
    res.status(404).json({ error: 'Schedule item or substitute teacher not found' });
  }
});



// Dynamic substitution recomendations matching
app.post('/api/schedules/substitute-recommend', (req, res) => {
  const { scheduleItemId } = req.body;
  const targetItem = schedules.find(s => s.id === scheduleItemId);

  if (!targetItem) {
    return res.status(404).json({ error: 'Target schedule item not found' });
  }

  const day = targetItem.day;
  const period = targetItem.period;

  const recommendations: SubstituteRecommendation[] = [];

  // Match: same-subject teachers, Sport teachers or Free teachers
  for (const t of teachers) {
    if (t.id === targetItem.teacherId) continue; // skip regular teacher

    // 1. Check if substitute has a conflicting class scheduled at this slot
    const hasConflict = schedules.some(s => s.teacherId === t.id && s.day === day && s.period === period && !s.isFinished);

    // 2. Check current weekly load for substitute
    const currentWeeklyLoad = schedules.filter(s => s.teacherId === t.id && !s.isFinished).length;

    // 3. Compute suitability score
    let score = 50; // base score
    const reasons: string[] = [];

    // Is it the same subject? (+35 points)
    const isSameSubject = t.subjects.includes(targetItem.subject);
    if (isSameSubject) {
      score += 35;
      reasons.push(`同科目教师 (教授 ${targetItem.subject})`);
    } else {
      reasons.push(`不同科目教师 (教授 ${t.subjects.join('/')})`);
    }

    // Weekly load capacity comparison: Lower current load is preferred (+15 to -10 points)
    const capacityRemaining = t.maxWeeklyHours - currentWeeklyLoad;
    if (capacityRemaining > 4) {
      score += 15;
      reasons.push(`教学周课时充沛 (当前已排 ${currentWeeklyLoad}/${t.maxWeeklyHours} 节)`);
    } else if (capacityRemaining <= 0) {
      score -= 20;
      reasons.push(`已达到最大周课时负荷 (当前已排 ${currentWeeklyLoad}/${t.maxWeeklyHours} 节)`);
    } else {
      score += 5;
      reasons.push(`课时富余较小 (当前已排 ${currentWeeklyLoad}/${t.maxWeeklyHours} 节)`);
    }

    // Check if slot falls in teacher's specific preferred/unavailable slots (-30 points)
    const isSlotInUnavailable = t.unavailablePeriods.some(p => p.day === day && p.period === period);
    if (isSlotInUnavailable) {
      score -= 30;
      reasons.push(`时段冲突: 被标记为教师偏好不可排时段`);
    }

    if (hasConflict) {
      score = 0; // cannot make recommendation if they have their own class
      reasons.push(`严重冲突: 教师在同一时段有其他课时`);
    }

    // Bound the score
    score = Math.max(0, Math.min(100, score));

    recommendations.push({
      teacher: t,
      suitabilityScore: score,
      reasons,
      hasConflictOnChosenSlot: hasConflict,
      currentWeeklyLoad
    });
  }

  // Sort by suitability
  recommendations.sort((a, b) => b.suitabilityScore - a.suitabilityScore);

  res.json({
    item: targetItem,
    recommendations: recommendations.slice(0, 5) // Return top 5 matches
  });
});

// Timetable dynamic course-shifting (e.g. General technology exam completions)
app.post('/api/schedules/timetable-shift', (req, res) => {
  const { subject, effectiveWeekStart, reason } = req.body;

  // Set lessons of this subject to finished in memory
  schedules = schedules.map(s => {
    if (s.subject === subject) {
      return {
        ...s,
        isFinished: true,
        finishedWeek: effectiveWeekStart
      };
    }
    return s;
  });

  aiInsightsCache = null;

  const currentConflicts = detectConflicts(schedules, teachers, classrooms, teachingClasses);
  res.json({
    status: 'success',
    schedules,
    conflicts: currentConflicts,
    message: `成功更新：${subject} 课程在第 ${effectiveWeekStart} 周考核完成后已全学期即时停用，释放后续教室及教师。`
  });
});

// Snapshot Rollbacks
app.post('/api/schedules/save-snapshot', (req, res) => {
  const { name, description } = req.body;
  const historyId = `hist_${Date.now()}`;
  histories.push({
    id: historyId,
    name: name || `第${histories.length + 1}次动态微调`,
    timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    description: description || '无描述',
    items: JSON.parse(JSON.stringify(schedules))
  });
  res.json({ status: 'success', histories });
});

app.post('/api/schedules/rollback', (req, res) => {
  const { historyId } = req.body;
  const hit = histories.find(h => h.id === historyId);
  if (hit) {
    schedules = JSON.parse(JSON.stringify(hit.items));
    aiInsightsCache = null;
    const currentConflicts = detectConflicts(schedules, teachers, classrooms, teachingClasses);
    res.json({ status: 'success', schedules, conflicts: currentConflicts });
  } else {
    res.status(404).json({ error: 'Snapshot not found' });
  }
});


// Excel mock dynamic imports
app.post('/api/data/import', (req, res) => {
  const { type, list } = req.body;
  if (type === 'teacher') {
    list.forEach((t: any) => {
      const idx = teachers.findIndex(item => item.name === t.name);
      if (idx !== -1) {
        teachers[idx] = { ...teachers[idx], ...t };
      } else {
        teachers.push({
          id: `T${String(teachers.length + 1).padStart(3, '0')}`,
          name: t.name || '未知老师',
          subjects: [t.subject || '语文'],
          maxWeeklyHours: t.maxWeeklyHours || 16,
          maxDailyHours: 4,
          maxConsecutiveLessons: 2,
          unavailablePeriods: [],
          preferences: '暂无偏好',
          phone: t.phone || '',
          email: t.email || '',
          department: t.department || '综合组'
        });
      }
    });
  } else if (type === 'classroom') {
    list.forEach((rawRoom: any) => {
      classrooms.push({
        id: `R${String(classrooms.length + 1).padStart(3, '0')}`,
        name: rawRoom.name || '走班定制教室',
        type: rawRoom.type || 'ordinary',
        capacity: rawRoom.capacity || 40,
        assignedSubjects: [rawRoom.subject || '普通']
      });
    });
  }

  const currentConflicts = detectConflicts(schedules, teachers, classrooms, teachingClasses);
  res.json({ status: 'success', teachers, classrooms, schedules, conflicts: currentConflicts });
});

// JSON standard full database import/initialize route
app.post('/api/data/import-json', (req, res) => {
  const { teachers: newTeachers, classrooms: newClassrooms, teachingClasses: newTeachingClasses, students: newStudents, schedules: newSchedules } = req.body;
  
  if (Array.isArray(newTeachers)) teachers = newTeachers;
  if (Array.isArray(newClassrooms)) classrooms = newClassrooms;
  if (Array.isArray(newTeachingClasses)) teachingClasses = newTeachingClasses;
  if (Array.isArray(newStudents)) students = newStudents;
  if (Array.isArray(newSchedules)) schedules = newSchedules;
  
  histories = [];
  const currentConflicts = detectConflicts(schedules, teachers, classrooms, teachingClasses);
  res.json({ 
    status: 'success', 
    teachers, 
    classrooms, 
    teachingClasses, 
    students, 
    schedules, 
    conflicts: currentConflicts 
  });
});


// ---------------- Vite Middleware & Fallback ----------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
