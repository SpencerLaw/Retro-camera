import { useState, useEffect, useCallback } from 'react';
import { motion } from 'motion/react';

const WIN_SCORE = 10;

// 生成随机乘法题 (1~10)
const generateProblem = () => {
  const num1 = Math.floor(Math.random() * 9) + 2;
  const num2 = Math.floor(Math.random() * 9) + 2;
  return { num1, num2, answer: num1 * num2 };
};

// 数字小键盘组件
const Keypad = ({ onInput, onClear, onSubmit, team }: {
  onInput: (val: string) => void;
  onClear: () => void;
  onSubmit: () => void;
  team: 'blue' | 'red';
}) => {
  const buttons = [
    '1', '2', '3',
    '4', '5', '6',
    '7', '8', '9',
    '清除', '0', '确认'
  ];

  return (
    <div className="grid grid-cols-3 gap-2 w-full max-w-[320px]">
      {buttons.map((btn) => {
        let btnClass = "h-[56px] rounded-lg text-[22px] font-bold shadow-[0_2px_0_rgba(0,0,0,0.1)] active:translate-y-[2px] active:shadow-none transition-all flex items-center justify-center ";
        if (btn === '清除') {
          btnClass += "bg-slate-200 text-slate-800";
        } else if (btn === '确认') {
          btnClass += `col-span-2 text-white ${team === 'blue' ? 'bg-blue-600' : 'bg-red-600'}`;
        } else {
          btnClass += "bg-white text-slate-800";
        }

        return (
          <button
            key={btn}
            onClick={() => {
              if (btn === '清除') onClear();
              else if (btn === '确认') onSubmit();
              else onInput(btn);
            }}
            className={btnClass}
          >
            {btn}
          </button>
        );
      })}
    </div>
  );
};

export default function App() {
  // 游戏状态：score 为负数表示蓝队优势，正数表示红队优势
  const [score, setScore] = useState(0);
  const [blueProblem, setBlueProblem] = useState(generateProblem());
  const [redProblem, setRedProblem] = useState(generateProblem());
  const [blueInput, setBlueInput] = useState('');
  const [redInput, setRedInput] = useState('');
  const [gameState, setGameState] = useState<'playing' | 'blue_wins' | 'red_wins'>('playing');
  const [timeElapsed, setTimeElapsed] = useState(0);

  // 计时器逻辑
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (gameState === 'playing') {
      timer = setInterval(() => {
        setTimeElapsed((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [gameState]);

  // 蓝队提交答案
  const handleBlueSubmit = useCallback(() => {
    if (gameState !== 'playing') return;
    if (parseInt(blueInput) === blueProblem.answer) {
      // 答对，分数减1（向蓝队移动）
      const newScore = score - 1;
      setScore(newScore);
      setBlueProblem(generateProblem());
      setBlueInput('');
      // 判断是否达到胜利线
      if (newScore <= -WIN_SCORE) {
        setGameState('blue_wins');
      }
    } else {
      // 答错，清空输入框，题目不刷新
      setBlueInput('');
    }
  }, [blueInput, blueProblem, score, gameState]);

  // 红队提交答案
  const handleRedSubmit = useCallback(() => {
    if (gameState !== 'playing') return;
    if (parseInt(redInput) === redProblem.answer) {
      // 答对，分数加1（向红队移动）
      const newScore = score + 1;
      setScore(newScore);
      setRedProblem(generateProblem());
      setRedInput('');
      // 判断是否达到胜利线
      if (newScore >= WIN_SCORE) {
        setGameState('red_wins');
      }
    } else {
      // 答错，清空输入框，题目不刷新
      setRedInput('');
    }
  }, [redInput, redProblem, score, gameState]);

  // 重新开始游戏
  const resetGame = () => {
    setScore(0);
    setBlueProblem(generateProblem());
    setRedProblem(generateProblem());
    setBlueInput('');
    setRedInput('');
    setGameState('playing');
    setTimeElapsed(0);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-50 text-slate-800 font-sans select-none overflow-hidden">
      {/* 顶部区域：标题和计时器 */}
      <header className="h-[80px] bg-white border-b-2 border-slate-200 flex items-center justify-between px-10 z-10 shrink-0">
        <div className="text-[28px] font-extrabold tracking-tight">
          数学拔河 <span className="font-light opacity-60">Tug of War</span>
        </div>
        <div className="font-mono text-[24px] font-bold text-slate-500">
          {Math.floor(timeElapsed / 60).toString().padStart(2, '0')}:{(timeElapsed % 60).toString().padStart(2, '0')}
        </div>
      </header>

      {/* 中间区域：拔河视觉表现 */}
      <div className="h-[120px] bg-white flex items-center justify-center relative border-b border-slate-200 shrink-0 px-[100px]">
        {/* 绳子 */}
        <div className="w-full h-2 bg-slate-300 rounded-full relative">
          {/* 胜利线区域 */}
          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-10 bg-slate-400 border-l-2 border-blue-600"></div>
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-10 bg-slate-400 border-r-2 border-red-600"></div>

          {/* 红心标记 */}
          <motion.div
            className="absolute top-1/2 w-[36px] h-[36px] bg-red-500 border-4 border-white rounded-full shadow-[0_0_15px_rgba(0,0,0,0.2)] z-10"
            animate={{
              left: `calc(50% + ${(score / WIN_SCORE) * 50}%)`,
              y: '-50%',
              x: '-50%'
            }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
          />
        </div>
      </div>

      {/* 下半部分：左右分屏对战区 */}
      <main className="flex-1 grid grid-cols-2 min-h-0">
        {/* 左半边：蓝队 */}
        <section className="bg-blue-50 border-r border-slate-200 flex flex-col items-center p-5 overflow-y-auto">
          <div className="text-[24px] font-bold text-blue-600 mb-5 mt-4">蓝队 BLUE TEAM</div>
          
          <div className="bg-white rounded-2xl p-6 w-full max-w-[320px] shadow-sm text-center mb-5 flex flex-col items-center">
            <div className="text-[48px] font-extrabold text-slate-800 mb-3">
              {blueProblem.num1} × {blueProblem.num2} = ?
            </div>
            <div className="h-[60px] w-[160px] text-[40px] font-bold text-slate-700 border-b-4 border-slate-300 flex items-center justify-center mb-2">
              {blueInput}
            </div>
          </div>
          
          <Keypad
            onInput={(val) => setBlueInput(prev => (prev.length < 3 ? prev + val : prev))}
            onClear={() => setBlueInput('')}
            onSubmit={handleBlueSubmit}
            team="blue"
          />
        </section>

        {/* 右半边：红队 */}
        <section className="bg-red-50 flex flex-col items-center p-5 overflow-y-auto">
          <div className="text-[24px] font-bold text-red-600 mb-5 mt-4">红队 RED TEAM</div>
          
          <div className="bg-white rounded-2xl p-6 w-full max-w-[320px] shadow-sm text-center mb-5 flex flex-col items-center">
            <div className="text-[48px] font-extrabold text-slate-800 mb-3">
              {redProblem.num1} × {redProblem.num2} = ?
            </div>
            <div className="h-[60px] w-[160px] text-[40px] font-bold text-slate-700 border-b-4 border-slate-300 flex items-center justify-center mb-2">
              {redInput}
            </div>
          </div>
          
          <Keypad
            onInput={(val) => setRedInput(prev => (prev.length < 3 ? prev + val : prev))}
            onClear={() => setRedInput('')}
            onSubmit={handleRedSubmit}
            team="red"
          />
        </section>
      </main>

      {/* 游戏结束弹窗 */}
      {gameState !== 'playing' && (
        <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center z-50 text-white">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex flex-col items-center"
          >
            <h2 className="text-[80px] font-bold mb-5">
              {gameState === 'blue_wins' ? '蓝队获胜!' : '红队获胜!'}
            </h2>
            <button
              onClick={resetGame}
              className="px-10 py-[15px] text-[24px] font-bold rounded-full bg-white text-slate-900 cursor-pointer hover:bg-gray-200 transition-colors"
            >
              重新开始游戏
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}
